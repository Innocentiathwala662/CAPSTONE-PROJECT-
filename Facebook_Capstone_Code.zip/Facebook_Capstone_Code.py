
# Facebook Page Metrics Analysis – Code

# 1. Import Libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import ttest_ind

# Inline plotting for Jupyter
%matplotlib inline

# 2. Load Data
df = pd.read_csv('FacebookMetrics.csv')
df.head()

# 3. Data Understanding
df.info()
df.describe()
df.isnull().sum()

# 4. Data Cleaning
df = df.dropna()
df = df.drop_duplicates()
df['Paid'] = df['Paid'].astype(int)

Q1 = df['Total Interactions'].quantile(0.25)
Q3 = df['Total Interactions'].quantile(0.75)
IQR = Q3 - Q1
df = df[(df['Total Interactions'] >= Q1 - 1.5*IQR) & (df['Total Interactions'] <= Q3 + 1.5*IQR)]

# 5. Exploratory Data Analysis (EDA)
df.describe(include='all')

plt.figure(figsize=(8,5))
sns.histplot(df['Total Interactions'], bins=30, kde=True)
plt.title('Distribution of Total Interactions')
plt.xlabel('Total Interactions')
plt.show()

plt.figure(figsize=(6,4))
sns.countplot(x='Type', data=df)
plt.title('Count of Posts by Type')
plt.xlabel('Post Type')
plt.ylabel('Count')
plt.show()

plt.figure(figsize=(8,5))
sns.boxplot(x='Type', y='Total Interactions', data=df)
plt.title('Total Interactions by Post Type')
plt.xlabel('Post Type')
plt.ylabel('Total Interactions')
plt.show()

plt.figure(figsize=(8,6))
corr = df[['Likes', 'Comments', 'Shares', 'Total Interactions']].corr()
sns.heatmap(corr, annot=True, cmap='coolwarm')
plt.title('Correlation Matrix')
plt.show()

# 6. Hypothesis Testing
paid = df[df['Paid'] == 1]['Total Interactions']
unpaid = df[df['Paid'] == 0]['Total Interactions']

t_stat, p_value = ttest_ind(paid, unpaid, equal_var=False)
print(f"T-statistic: {t_stat:.2f}, P-value: {p_value:.4f}")

if p_value < 0.05:
    print("Conclusion: Significant difference between Paid and Unpaid posts.")
else:
    print("Conclusion: No significant difference between Paid and Unpaid posts.")

# 7. Conclusion
# - Post Type strongly predicts interactions
# - Paid promotion did not show statistically significant improvement
# - Recommendation: Prioritise high-performing content types and test Paid strategies
